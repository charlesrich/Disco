This folder contains all the library files needed to run Disco and
associated commands.

See bin/README.txt

