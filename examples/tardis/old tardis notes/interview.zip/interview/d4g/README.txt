This is the README file for disco/d4g.  It contains files that are
needed only if you are using Disco for Games (D4g). 

See also bin/d4g2018

rich@wpi.edu   5/6/11
