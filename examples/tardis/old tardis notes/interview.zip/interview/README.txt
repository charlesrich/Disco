This is the root folder for prototype Disco models for TARDIS project.
See README.txt files in each subfolder.
